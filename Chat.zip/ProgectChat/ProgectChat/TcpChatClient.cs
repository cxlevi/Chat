﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ProgectChat
{
    public class TcpChatClient
    {
        private TcpClient _client;
        private NetworkStream _stream;

        public event Action<string> MessageReceived;

        public async Task ConnectAsync(string host, int port, int userId)
        {
            _client = new TcpClient();
            await _client.ConnectAsync(host, port);
            _stream = _client.GetStream();

            // Отправляем ID на сервер
            var userIdMessage = $"USERID:{userId}";
            await SendMessageAsync(userIdMessage);

            // Начинаем приём сообщений асинхронно
            _ = Task.Run(ReceiveMessagesAsync);
        }


        private async Task ReceiveMessagesAsync()
        {
            using var reader = new StreamReader(_stream, Encoding.UTF8);

            while (true)
            {
                string line = await reader.ReadLineAsync();  // Асинхронно читаем строку
                if (line == null) break;

                // Обрабатываем полученные сообщения
                MessageReceived?.Invoke(line);
            }
        }

        public async Task SendMessageAsync(string message)
        {
            if (_stream != null && _stream.CanWrite)
            {
                byte[] data = Encoding.UTF8.GetBytes(message + "\n");
                await _stream.WriteAsync(data, 0, data.Length);
                Console.WriteLine($"📤 Сообщение отправлено: {message}");
            }
        }
        public void Disconnect()
        {
            _stream?.Close(); // Закрытие потока
            _client?.Close(); // Закрытие клиента
        }
    }
}

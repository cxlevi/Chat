﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using Newtonsoft.Json;

namespace ProgectChat
{
    public class Logger
    {
        private string logFilePath = "log.json";  // Путь к файлу для логов

        // Уровни логирования
        public enum LogLevel
        {
            Info,
            Warning,
            Error
        }

        // Структура лог-сообщений
        public class LogEntry
        {
            public string Timestamp { get; set; }
            public LogLevel Level { get; set; }
            public string Message { get; set; }
        }

        public Logger()
        {
            // Проверяем, существует ли файл. Если нет, создаем его.
            if (!File.Exists(logFilePath))
            {
                // Если файл не существует, создаем пустой файл и добавляем пустой список логов.
                var emptyLogs = new List<LogEntry>();
                var json = JsonConvert.SerializeObject(emptyLogs);
                File.WriteAllText(logFilePath, json);
            }
        }

        // Логирование сообщения с уровнем
        public void Log(LogLevel level, string message)
        {
            try
            {
                // Создаем объект LogEntry с текущим временем, уровнем и сообщением
                var logEntry = new LogEntry
                {
                    Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    Level = level,
                    Message = message
                };

                // Чтение существующих логов из файла
                List<LogEntry> logEntries = new List<LogEntry>();
                var existingLogs = File.ReadAllText(logFilePath);
                logEntries = JsonConvert.DeserializeObject<List<LogEntry>>(existingLogs) ?? new List<LogEntry>();

                // Добавляем новый лог в список
                logEntries.Add(logEntry);

                // Сериализация списка логов в JSON и запись в файл
                var json = JsonConvert.SerializeObject(logEntries, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(logFilePath, json);
            }
            catch (Exception ex)
            {
                // Если возникла ошибка при записи в лог, выводим ошибку
                Console.WriteLine($"Ошибка при записи в лог: {ex.Message}");
            }
        }

        // Логирование информационного сообщения
        public void LogInfo(string message)
        {
            Log(LogLevel.Info, message);
        }

        // Логирование предупреждения
        public void LogWarning(string message)
        {
            Log(LogLevel.Warning, message);
        }

        // Логирование ошибки
        public void LogError(string message)
        {
            Log(LogLevel.Error, message);
        }
    }
}

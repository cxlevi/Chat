﻿using Newtonsoft.Json;
using ProgectChat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class LogParser
{
    public static ObservableCollection<ParsedMessage> ParseLogs(string json)
    {
        var logEntries = JsonConvert.DeserializeObject<List<LogEntry>>(json);
        var parsedMessages = new ObservableCollection<ParsedMessage>();

        foreach (var entry in logEntries)
        {
            if (entry.Level != 0) continue; // Фильтруем по уровню
            if (entry.Message.Contains("All messages logged")) continue; // Пропускаем общий лог

            if (MessageParser.TryParse(entry.Message, out var parsed))
            {
                parsedMessages.Add(parsed);
            }
        }

        return parsedMessages;
    }

    public class LogEntry
    {
        public string Timestamp { get; set; }
        public int Level { get; set; }
        public string Message { get; set; }
    }
}

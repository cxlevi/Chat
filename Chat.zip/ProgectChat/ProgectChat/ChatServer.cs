﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace ProgectChat
{
    public class MySqlChatService
    {
        private readonly string connectionString;

        public MySqlChatService()
        {
            connectionString = "Server=sql8.freesqldatabase.com;" +
                                   "Database=sql8771867;" +
                                   "User=sql8771867;" +
                                   "Password=zhx9FVLUs5;" +
                                   "Port=3306;" +
                                   "CharSet=utf8mb4;";
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string EncodeLogin(string login)
        {
            return login; // Не кодируем логин, просто используем его в том виде, в котором он передается
        }


        public bool TestConnection()
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    var query = "SELECT 1";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        var result = command.ExecuteScalar();
                        return result != null && result.ToString() == "1";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public void AddUser(string login, string name, string password)
        {
            string encodedLogin = EncodeLogin(login);  // Кодируем логин (если нужно)
            string salt = GenerateSalt();  // Генерируем соль
            string hashedPassword = HashPasswordWithSalt(password, salt);  // Хешируем пароль с солью

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                var query = "INSERT INTO Users (UserLogin, UserName, UserPassword, Salt) VALUES (@Login, @Name, @Password, @Salt)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", encodedLogin);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Password", hashedPassword);
                    command.Parameters.AddWithValue("@Salt", salt);

                    int rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected > 0 ? "Пользователь успешно добавлен!" : "Ошибка при добавлении пользователя.", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        public void CreateChat(string chatData)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                var query = "INSERT INTO Chats (ChatData) VALUES (@ChatData)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatData", chatData);

                    int rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected > 0 ? "Чат успешно создан!" : "Ошибка при создании чата.", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        public void AddUserToChat(int userId, int chatId)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                var query = "INSERT INTO UserChats (UserID, ChatID) VALUES (@UserID, @ChatID)";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);
                    command.Parameters.AddWithValue("@ChatID", chatId);

                    int rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected > 0 ? "Пользователь успешно добавлен в чат!" : "Ошибка при добавлении пользователя в чат.", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        public void ListUsers()
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var query = "SELECT UserID, UserLogin, UserName FROM Users";
                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    StringBuilder usersList = new StringBuilder("Список пользователей:\n");
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            usersList.AppendLine($"ID: {reader["UserID"]}, Логин: {reader["UserLogin"]}, Имя: {reader["UserName"]}");
                        }
                        MessageBox.Show(usersList.ToString(), "Пользователи", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("В базе данных нет пользователей.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        public void ListChats()
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var query = "SELECT ChatID, ChatData, CreatedAt FROM Chats";
                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    StringBuilder chatList = new StringBuilder("Список чатов:\n");
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            chatList.AppendLine($"ID: {reader["ChatID"]}, Данные: {reader["ChatData"]}, Дата создания: {reader["CreatedAt"]}");
                        }
                        MessageBox.Show(chatList.ToString(), "Чаты", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("В базе данных нет чатов.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private string GenerateSalt()
        {
            byte[] saltBytes = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(saltBytes);
            }
            return Convert.ToBase64String(saltBytes);
        }

        private string HashPasswordWithSalt(string password, string salt)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password + salt);  // Добавляем соль к паролю
                byte[] hashedBytes = sha256.ComputeHash(passwordBytes);
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashedBytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }




        public bool AuthenticateUser(string login, string password)
        {
            string encodedLogin = EncodeLogin(login);  // Кодируем логин (если нужно)
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                var query = "SELECT UserPassword, Salt FROM Users WHERE UserLogin = @Login";
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", encodedLogin);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            string storedHash = reader["UserPassword"].ToString();  // Хеш пароля из базы
                            string storedSalt = reader["Salt"].ToString();  // Соль из базы

                            // Хешируем введённый пароль с той же солью
                            string hashedPassword = HashPasswordWithSalt(password, storedSalt);

                            // Сравниваем хеши
                            if (storedHash.Equals(hashedPassword, StringComparison.OrdinalIgnoreCase))
                            {
                                MessageBox.Show("Успешная авторизация!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return true;  // Пароль правильный
                            }
                            else
                            {
                                MessageBox.Show("Неверный пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return false;  // Неверный пароль
                            }
                        }
                        else
                        {
                            MessageBox.Show("Пользователь не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;  // Пользователь не найден
                        }
                    }
                }
            }
        }

    }
}

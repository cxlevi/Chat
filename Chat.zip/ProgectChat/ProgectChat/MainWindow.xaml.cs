﻿using System.Windows;  // Добавьте эту строку, чтобы избежать неоднозначности с MessageBox
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ProgectChat
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MouseLeftButtonDown += (s, e) => DragMove(); // Движение окна
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow registrationWindow = new RegistrationWindow();
            registrationWindow.Show();
            Close();
        }

        private void EntryButton_Click(object sender, RoutedEventArgs e)
        {
            string login = EmailOrLoginTextBox.Text;
            string password = PasswordBox.Password;

            MySqlChatService chatService = new MySqlChatService();  // Создаем объект сервиса для работы с базой данных

            // Проверяем, правильный ли логин и пароль
            bool isAuthenticated = chatService.AuthenticateUser(login, password);

            if (isAuthenticated)
            {
                // Если авторизация успешна, открываем окно чата
                ChatWindow chatWindow = new ChatWindow(login);  // Предполагаем, что это окно чатов или основное окно
                chatWindow.Show();  // Открываем новое окно
                this.Close();  // Закрываем окно авторизации
            }
            else
            {
                // Очистим поля ввода (по желанию)
                EmailOrLoginTextBox.Clear();
                PasswordBox.Clear();
                EmailOrLoginTextBox.Focus();  // Возвращаем фокус на поле для логина
            }
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

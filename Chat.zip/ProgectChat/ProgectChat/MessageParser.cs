﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ProgectChat
{
    public static class MessageParser
    {
        private static readonly Regex _messageRegex = new Regex(
            @"^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}) - (\w+ \d+): (.+)$",
            RegexOptions.Compiled
        );

        public static bool TryParse(string message, out ParsedMessage parsedMessage)
        {
            parsedMessage = null;
            var match = _messageRegex.Match(message);
            if (match.Success)
            {
                parsedMessage = new ParsedMessage
                {
                    Date = match.Groups[1].Value,
                    Time = match.Groups[2].Value,
                    Sender = match.Groups[3].Value,
                    Content = match.Groups[4].Value
                };
                return true;
            }
            return false;
        }
    }

    public class ParsedMessage
    {
        public string Date { get; set; }
        public string Time { get; set; }
        public string Sender { get; set; }
        public string Content { get; set; }

        public string FormattedMessage
        {
            get => $"{Date} {Time} - {Sender}: {Content}";
        }
    }
}

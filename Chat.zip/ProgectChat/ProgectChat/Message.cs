﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgectChat
{
    public class Message
    {
        public int MessageID { get; set; }             // Уникальный идентификатор сообщения
        public int SenderID { get; set; }              // ID отправителя
        public int? ReceiverID { get; set; }           // ID получателя (может быть null для сообщений в группу)
        public int? GroupID { get; set; }              // ID группы (может быть null для личных сообщений)
        public string MessageText { get; set; }        // Текст сообщения
        public DateTime CreatedAt { get; set; }      // Время отправки сообщения
        public bool IsOutgoing { get; set; }           // Время отправки сообщения

        // Навигационные свойства для связей с другими таблицами
        public User Sender { get; set; }               // Связь с отправителем
        public User Receiver { get; set; }             // Связь с получателем
        public Group Group { get; set; }               // Связь с группой
        public bool IsUserMessage { get; set; }
}
}

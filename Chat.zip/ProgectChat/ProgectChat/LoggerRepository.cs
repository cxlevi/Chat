﻿using System.Collections.Generic;
using System.IO;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace ProgectChat
{
    public class LoggerRepository
    {
        private string connectionString = "Server=sql7.freesqldatabase.com;" +
                                          "Database=sql7767544;" +
                                          "User=sql7767544;" +
                                          "Password=G679eUayjA;" +
                                          "Port=3306;";

        private string logFilePath = "log.json"; // Путь к JSON файлу

        public void WriteLogsToDatabase()
        {
            // Чтение логов из JSON файла
            var jsonLogs = File.ReadAllText(logFilePath);
            var logEntries = JsonConvert.DeserializeObject<List<Logger.LogEntry>>(jsonLogs);

            if (logEntries == null || logEntries.Count == 0) return;

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                foreach (var log in logEntries)
                {
                    string query = "INSERT INTO Chats (ChatData, CreatedAt) VALUES (@ChatData, @CreatedAt)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ChatData", log.Message);
                        command.Parameters.AddWithValue("@CreatedAt", log.Timestamp);

                        command.ExecuteNonQuery();
                    }
                }
            }
        }
    }
}
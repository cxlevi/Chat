﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Schema;

namespace ProgectChat
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        MySqlChatService chatService = new MySqlChatService();  
        public RegistrationWindow()
        {
            InitializeComponent();
            MouseLeftButtonDown += (s, e) => DragMove(); // Движение окна
        }

        private void Registration_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginOrEmailTextBox.Text))
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Red);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Green);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(UserNameTB.Text))
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Red);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Green);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(AgainPasswordBox.Password))
            {

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (PasswordBox.Password != AgainPasswordBox.Password)
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                return;
            }
            else
            {

                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            AddUser(chatService);  
        }

        private void EntryButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void AddUser(MySqlChatService chatService)
        {
            string login = LoginOrEmailTextBox.Text;

            string name = UserNameTB.Text;

            string password = PasswordBox.Password;

            string AgainPassword = AgainPasswordBox.Password;

            if (password != AgainPassword)
            {
                MessageBox.Show("Пароли не совпадают!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                chatService.AddUser(login, name, password);
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            }
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

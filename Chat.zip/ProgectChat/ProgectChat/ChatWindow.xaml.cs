﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NAudio.CoreAudioApi;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using Microsoft.VisualBasic.ApplicationServices;
using System.Windows.Shell;
using MahApps.Metro.Controls.Dialogs;
using System.Xml.Linq;
using System.Data;
using System.Windows.Threading;
using System.Net.Sockets;
using System.Net;

namespace ProgectChat
{
    /// <summary>
    /// Логика взаимодействия для ChatWindow.xaml
    /// </summary>
    public partial class ChatWindow : Window
    {
        static private List<User> existingUsers;
        private MySqlChatService chatService = new MySqlChatService();
        private int currentUserId;
        private static string connectionString;
        public ObservableCollection<User> ChosenUsers { get; set; } = new ObservableCollection<User>();
        public ObservableCollection<Group> Groups { get; set; } = new ObservableCollection<Group>();
        public ObservableCollection<IChatItem> CombinedList { get; set; } = new ObservableCollection<IChatItem>();
        private readonly MMDevice _audioDevice;
        private readonly Logger _logger = new Logger();
        private string login;
        private DispatcherTimer pollTimer;
        private TcpChatClient _chatClient = new TcpChatClient();
        private string _nickname = "User_" + new Random().Next(1000, 9999);
        private int lastReceiverId = -1;
        private int currentReceiverUserId = -1;
        private int currentGroupId = -1;
        private User selectedUser;
        private Group selectedGroup;


        public ChatWindow(string name)
        {
            login = name;
            InitializeComponent();

            this.DataContext = this;
            // Устройство вывода звука
            var deviceEnumerator = new MMDeviceEnumerator();
            CombinedList = new ObservableCollection<IChatItem>(LoadData());
            _audioDevice = deviceEnumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);


            MouseLeftButtonDown += (s, e) => DragMove();
        }
        private void MessageTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                SendButton_Click(sender, e); // Отправляем сообщение, как если бы нажали кнопку
            }
        }
        private void AddMessageToChat(string message)
        {
            // Создаем новый TextBlock для сообщения
            TextBlock messageTextBlock = new TextBlock
            {
                Text = message,
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14
            };

            // Добавляем сообщение в MessagesPanel
            MessagesPanel.Children.Add(messageTextBlock);

            // Прокручиваем ScrollViewer, чтобы показывать последнее сообщение
            MessageList.ScrollToEnd();
        }
        private async void HandleMessageReceived(string message)
        {
            // Пример: FROM:1|Привет!
            if (message.StartsWith("FROM:"))
            {
                var parts = message.Split('|');
                if (parts.Length >= 3)
                {
                    string senderIdStr = parts[0].Substring(5);
                    string senderName = parts[1];
                    string text = parts[2];

                    if (int.TryParse(senderIdStr, out int senderId))
                    {
                        if (senderId == currentUserId)
                            return;

                        // Формируем полное сообщение для отображения в UI
                        var fullText = $"{senderName}: {text}";
                        var messageBubble = CreateMessageBubble(fullText, false, DateTime.Now.ToString("HH:mm"));
                        MessagesPanel.Children.Add(messageBubble);

                        // Обновляем UI с использованием Dispatcher для асинхронных операций
                        Dispatcher.Invoke(() =>
                        {
                            MessagesPanel.UpdateLayout();
                            (MessagesPanel.Parent as ScrollViewer)?.ScrollToBottom();
                        });
                    }
                }
            }
            else
            {
                // Если сообщение не от пользователя (например, широковещательное)
                var messageBubble = CreateMessageBubble(message, false, DateTime.Now.ToString("HH:mm"));
                MessagesPanel.Children.Add(messageBubble);

                // Прокручиваем до последнего сообщения
                Dispatcher.Invoke(() =>
                {
                    MessagesPanel.UpdateLayout();
                    (MessagesPanel.Parent as ScrollViewer)?.ScrollToBottom();
                });
            }
        }
        public List<User> GetAllUsers()
        {
            var users = new List<User>();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT UserID, UserLogin, UserName FROM Users";
                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var user = new User
                        {
                            UserID = reader.GetInt32("UserID"),
                            UserLogin = reader.GetString("UserLogin"),
                            UserName = reader.GetString("UserName")
                        };
                        users.Add(user);
                        Console.WriteLine($"User loaded: {user.UserName}");
                    }
                }
            }

            return users;
        }

        public List<Group> GetAllGroups()
        {
            var groups = new List<Group>();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT GroupID, GroupName FROM Groups";
                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var group = new Group
                        {
                            GroupID = reader.GetInt32("GroupID"),
                            GroupName = reader.GetString("GroupName")
                        };
                        groups.Add(group);
                        Console.WriteLine($"Group loaded: {group.GroupName}");
                    }
                }
            }

            return groups;
        }
        private List<IChatItem> LoadData()
        {
            var users = GetAllUsers();
            var groups = GetAllGroups();

            var combinedList = new List<IChatItem>();
            combinedList.AddRange(users);  // Добавляем всех пользователей
            combinedList.AddRange(groups); // Добавляем группы

            return combinedList;  // Возвращаем комбинированный список
        }

        private void LoadChatList()
        {
            // Загружаем данные
            var combinedList = LoadData();

            // Исключаем текущего пользователя
            var filteredList = combinedList.Where(item =>
                !(item is User user && user.UserID == currentUserId)).ToList();

            // Создаём ObservableCollection для ListView
            CombinedList = new ObservableCollection<IChatItem>(filteredList);
            ChatList.ItemsSource = CombinedList;
        }
        private void LoadUserGroups()
        {
            // Получаем текущего пользователя
            var currentUser = chatService.GetUser(login);  // где currentUserLogin — это логин текущего пользователя
            if (currentUser != null)
            {
                // Получаем группы для текущего пользователя
                var userGroups = GetGroupsForUser(currentUser.UserID);

                // Отображаем группы в ListView (или другом элементе управления)
                ChatList.ItemsSource = userGroups;
            }
            else
            {
                MessageBox.Show("Пользователь не найден в базе данных.");
                Close();
                return;
            }
            currentUserId = currentUser.UserID;
        }
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Инициализация сервисов
            if (chatService == null)
                chatService = new MySqlChatService();

            if (_chatClient == null)
                _chatClient = new TcpChatClient();

            var currentUser = chatService.GetUser(login);

            if (currentUser == null)
            {
                MessageBox.Show("Пользователь не найден в базе данных.");
                Close();
                return;
            }

            // ✅ Сохраняем ID текущего пользователя
            currentUserId = currentUser.UserID;

            // Загружаем список чатов
            LoadChatList();

            // Подключение к серверу
            try
            {
                await _chatClient.ConnectAsync("127.0.0.1", 8888, currentUserId);

                // Подписываемся на событие получения сообщений
                _chatClient.MessageReceived += async message =>
                {
                    // Важно использовать async внутри MessageReceived
                    await Dispatcher.BeginInvoke(new Action(() =>
                    {
                        HandleMessageReceived(message); // Вызов обработки полученного сообщения
                    }));
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к серверу: {ex.Message}");
            }
        }

        protected override void OnClosed(System.EventArgs e)
        {
            _chatClient.Disconnect();
            base.OnClosed(e);
        }

        public void SetCurrentUser(int userId)
        {
            currentUserId = userId;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(MessageTextBox.Text))
            {
                // Передаем сообщение для отправки
                SendMessage(MessageTextBox.Text, true); // true — если от текущего юзера
                MessageTextBox.Clear();  // Очищаем поле ввода после отправки
            }
        }

        private async Task<List<Message>> GetMessagesFromDatabase(int senderId, int receiverId)
        {
            var messages = new List<Message>();

            using (var connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();
                string query = @"
                SELECT MessageID, SenderID, ReceiverID, MessageText, CreatedAt
                FROM Messages
                WHERE (SenderID = @SenderID AND ReceiverID = @ReceiverID)
                   OR (SenderID = @ReceiverID AND ReceiverID = @SenderID)
                ORDER BY CreatedAt";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SenderID", senderId);
                    command.Parameters.AddWithValue("@ReceiverID", receiverId);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            messages.Add(new Message
                            {
                                MessageID = reader.GetInt32("MessageID"),
                                SenderID = reader.GetInt32("SenderID"),
                                ReceiverID = reader.GetInt32("ReceiverID"),
                                MessageText = reader.GetString("MessageText"),
                                CreatedAt = reader.GetDateTime("CreatedAt"),
                                IsUserMessage = reader.GetInt32("SenderID") == senderId
                            });
                        }
                    }
                }
            }

            return messages;
        }

        private async void SendMessage(string text, bool isFromFirstUser)
        {
            if (string.IsNullOrWhiteSpace(text))
                return;

            var currentUser = chatService.GetUser(login); // Получаем текущего пользователя

            // Проверка, выбран ли получатель
            if (selectedUser != null)
            {
                // Отправка сообщения пользователю  
                var receiverUser = chatService.GetUser(selectedUser.UserLogin);
                if (receiverUser == null)
                {
                    MessageBox.Show("Выбранный пользователь не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string formattedMessage = $"TO:{receiverUser.UserID}|{text}";
                await _chatClient.SendMessageAsync(formattedMessage);
            }
            else if (selectedGroup != null)
            {
                // Отправка сообщения в группу
                var groupParticipants = GetGroupParticipants(selectedGroup.GroupID);  // Получаем участников группы (если нужно для других целей)

                // Используем реальное имя текущего пользователя
                string senderName = currentUser.UserName;  // Получаем имя отправителя

                // Формируем сообщение с именем отправителя для группы
                string formattedMessage = $"GROUP:{selectedGroup.GroupID}|{senderName}: {text}";
                await _chatClient.SendMessageAsync(formattedMessage);
            }
            else
            {
                // Если получатель не выбран
                MessageBox.Show("Получатель не выбран.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Добавляем сообщение в UI
            var messageBubble = CreateMessageBubble(text, isFromFirstUser, $"{DateTime.Now:HH:mm}", currentUser.UserName, isGroupMessage: selectedGroup != null);
            MessagesPanel.Children.Add(messageBubble);

            // Обновляем интерфейс
            MessagesPanel.Dispatcher.InvokeAsync(() =>
            {
                MessagesPanel.UpdateLayout();
                (MessagesPanel.Parent as ScrollViewer)?.ScrollToBottom();
            });
        }





        private Border CreateMessageBubble(string messageText, bool isFromFirstUser, string time, string senderName = null, bool isGroupMessage = false)
        {
            // Если это групповое сообщение, отображаем имя отправителя
            TextBlock senderTextBlock = null;
            if (isGroupMessage && !string.IsNullOrEmpty(senderName))
            {
                senderTextBlock = new TextBlock
                {
                    Text = $"{senderName}:",
                    FontWeight = FontWeights.Bold,
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 5),  // Отступ между именем и сообщением
                    Foreground = Brushes.LightBlue
                };
            }

            // Создаем блок для текста сообщения
            var messageTextBlock = new TextBlock
            {
                Text = messageText,
                FontSize = 14,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(5),
                Foreground = Brushes.White
            };

            // Создаем блок для времени сообщения
            var TimemessageTextBlock = new TextBlock
            {
                Text = $"{time}",
                FontSize = 9,
                Margin = new Thickness(3, 3, 0, 0),
                Foreground = Brushes.White
            };

            // Создаем основной контейнер для сообщения (StackPanel)
            var StackPanelMessage = new StackPanel
            {
                Orientation = Orientation.Vertical
            };

            // Добавляем в StackPanel элементы, если они не null
            if (senderTextBlock != null)
                StackPanelMessage.Children.Add(senderTextBlock);

            StackPanelMessage.Children.Add(messageTextBlock);
            StackPanelMessage.Children.Add(TimemessageTextBlock);

            // Создаем саму обертку для сообщения (Border)
            var messageBubble = new Border
            {
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF272727")),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(8),
                Margin = new Thickness(isFromFirstUser ? 50 : 5, 5, isFromFirstUser ? 5 : 50, 5),
                Child = StackPanelMessage,
                HorizontalAlignment = isFromFirstUser ? HorizontalAlignment.Right : HorizontalAlignment.Left
            };

            return messageBubble;
        }




        private void CreateTeamButton_Click(object sender, RoutedEventArgs e)
        {
            ShowWithAnimation3();
        }

        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
        }



        private void YourProfileButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ExitSettingGroupButton_Click(object sender, RoutedEventArgs e)
        {
            HideWithAnimation3();
        }

        private void SaveOrRediting_Click(object sender, RoutedEventArgs e)
        {

        }



    
        private void AddUsersButton_Click(object sender, RoutedEventArgs e)
        {
            string usernamesInput = UsersTextBox.Text.Trim();

            if (string.IsNullOrEmpty(usernamesInput))
            {
                MessageBox.Show("Введите логины пользователей через запятую.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string[] usernames = usernamesInput.Split(',')
                                               .Select(u => u.Trim())
                                               .Where(u => !string.IsNullOrEmpty(u))
                                               .ToArray();

            if (usernames.Length == 0)
            {
                MessageBox.Show("Список логинов пуст.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (string username in usernames)
                    {
                        string query = "SELECT UserID, UserLogin, UserName FROM Users WHERE UserLogin = @Login";
                        using (var command = new MySqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Login", username);
                            using (var reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    int userId = reader.GetInt32("UserID");
                                    string login = reader.GetString("UserLogin");
                                    string name = reader.GetString("UserName");

                                    // Проверка на дубли
                                    bool alreadyExists = ChosenUsers.Any(u => u.UserID == userId);
                                    if (!alreadyExists)
                                    {
                                        ChosenUsers.Add(new User
                                        {
                                            UserID = userId,
                                            UserLogin = login,
                                            UserName = name
                                        });
                                    }
                                }
                                else
                                {
                                    MessageBox.Show($"Пользователь '{username}' не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                                }
                            }
                        }
                    }

                    // Очищаем поле после добавления
                    UsersTextBox.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении пользователей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void CreateGroupButton_Click(object sender, RoutedEventArgs e)
        {
            string groupName = GroupNameTextBox.Text.Trim();
            string usernamesInput = UsersTextBox.Text.Trim();

            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Введите название группы.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Собираем логины из TextBox
            var usernamesFromText = usernamesInput.Split(',')
                                                   .Select(u => u.Trim())
                                                   .Where(u => !string.IsNullOrEmpty(u))
                                                   .ToList();

            // Добавляем пользователей из визуального списка (ChooseUsersList)
            var usernamesFromList = new List<string>();
            foreach (var item in ChooseUsersList.Items)
            {
                if (item is User user)
                    usernamesFromList.Add(user.UserLogin);
            }

            // Объединяем без дублей
            var allUsernames = usernamesFromText.Concat(usernamesFromList)
                                                 .Distinct()
                                                 .ToList();

            if (allUsernames.Count == 0)
            {
                MessageBox.Show("Список участников пуст.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            List<int> userIds = new List<int>();

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        // Получаем UserID для всех логинов
                        foreach (string username in allUsernames)
                        {
                            string query = "SELECT UserID FROM Users WHERE UserLogin = @Username";
                            using (var command = new MySqlCommand(query, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@Username", username);
                                object result = command.ExecuteScalar();

                                if (result != null)
                                    userIds.Add(Convert.ToInt32(result));
                                else
                                {
                                    // Логируем ошибку
                                    MessageBox.Show($"Пользователь '{username}' не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                                    transaction.Rollback();
                                    return;
                                }
                            }
                        }

                        // Добавляем текущего пользователя, если не включён
                        if (!userIds.Contains(currentUserId))
                            userIds.Add(currentUserId);

                        // Создаём группу
                        int groupId;
                        string insertGroupQuery = "INSERT INTO Groups (GroupName) VALUES (@GroupName); SELECT LAST_INSERT_ID();";
                        using (var command = new MySqlCommand(insertGroupQuery, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@GroupName", groupName);
                            groupId = Convert.ToInt32(command.ExecuteScalar());
                        }

                        // Добавляем всех участников в связующую таблицу GroupUsers
                        foreach (int userId in userIds)
                        {
                            string insertGroupUserQuery = "INSERT INTO GroupUsers (GroupID, UserID) VALUES (@GroupID, @UserID)";
                            using (var command = new MySqlCommand(insertGroupUserQuery, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@GroupID", groupId);
                                command.Parameters.AddWithValue("@UserID", userId);
                                command.ExecuteNonQuery();
                            }
                        }

                        // Завершаем транзакцию
                        transaction.Commit();

                        // Отображаем сообщение об успехе
                        MessageBox.Show($"Группа '{groupName}' успешно создана!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                        // Очищаем поля
                        GroupNameTextBox.Clear();
                        UsersTextBox.Clear();
                        ChooseUsersList.ItemsSource = null;

                        // Обновляем список групп в UI
                        if (DataContext is ChatWindow chatWindow)
                        {
                            Application.Current.Dispatcher.Invoke(() =>
                            {
                                // Добавляем группу в ObservableCollection, привязанную к ListView
                                chatWindow.Groups.Add(new Group
                                {
                                    GroupID = groupId,
                                    GroupName = groupName
                                });
                                chatWindow.ChatList.Items.Refresh();
                            });
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании группы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Console.WriteLine($"Детали ошибки: {ex.ToString()}");
            }
        }





        public void ShowWithAnimation3()
        {
            //SettingPanel.Visibility = Visibility.Visible;

            var animation = new DoubleAnimation
            {
                From = -ActualWidth,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            SlideTransform3.BeginAnimation(TranslateTransform.XProperty, animation);
        }


        public void HideWithAnimation3()
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = -ActualWidth,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            //animation.Completed += (s, e) => SettingPanel.Visibility = Visibility.Collapsed;
            SlideTransform3.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ничего тут сложного. Просто кнопки потыкайте и посмотрите что будет.");
        }


       

        private void ClearStoryChatsButton_Click(object sender, RoutedEventArgs e)
        {

        }



        public class MySqlChatService
        {
            public List<Message> GetMessagesBetweenUsers(int senderId, int receiverId)
            {
                List<Message> messages = new List<Message>();

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
            SELECT MessageID, SenderID, ReceiverID, MessageText, CreatedAt 
            FROM Messages
            WHERE (SenderID = @SenderID AND ReceiverID = @ReceiverID)
               OR (SenderID = @ReceiverID AND ReceiverID = @SenderID)
            ORDER BY CreatedAt";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SenderID", senderId);
                        command.Parameters.AddWithValue("@ReceiverID", receiverId);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var message = new Message
                                {
                                    MessageID = (int)reader["MessageID"],
                                    SenderID = (int)reader["SenderID"],
                                    ReceiverID = (int)reader["ReceiverID"],
                                    MessageText = reader["MessageText"].ToString(),
                                    CreatedAt = (DateTime)reader["CreatedAt"]
                                };
                                messages.Add(message);
                            }
                        }
                    }
                }

                return messages;
            }
            public List<Group> GetUserGroups(int userId)
            {
                var groups = new List<Group>();
                using var conn = new MySqlConnection(connectionString);
                conn.Open();

                string query = @"SELECT g.GroupID, g.GroupName
                     FROM Groups g
                     JOIN GroupUsers gu ON gu.GroupID = g.GroupID
                     WHERE gu.UserID = @userId";

                using var cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@userId", userId);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    groups.Add(new Group
                    {
                        GroupID = Convert.ToInt32(reader["GroupID"]),
                        GroupName = reader["GroupName"].ToString()
                    });
                }

                return groups;
            }


            public int CreateGroup(string name)
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                string query = "INSERT INTO Groups (GroupName) VALUES (@name); SELECT LAST_INSERT_ID();";
                using var cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", name);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }

            public void AddUserToGroup(int groupId, int userId)
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                string query = "INSERT INTO GroupUsers (GroupID, UserID) VALUES (@groupId, @userId)";
                using var cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@groupId", groupId);
                cmd.Parameters.AddWithValue("@userId", userId);
                cmd.ExecuteNonQuery();
            }

            public MySqlChatService()
            {
                connectionString = "Server=sql8.freesqldatabase.com;" +
                                   "Database=sql8771867;" +
                                   "User=sql8771867;" +
                                   "Password=zhx9FVLUs5;" +
                                   "Port=3306;" +
                                   "CharSet=utf8mb4;";
            }

            public void SaveUserProfileImage(int userId, byte[] imageBytes)
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE UserProfile SET ProfileImage = @ProfileImage WHERE Id = @UserID";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProfileImage", imageBytes);
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.ExecuteNonQuery();
                    }
                }
            }

            public User GetUser(string userLogin)
            {
                Console.WriteLine($"Поиск пользователя с логином: {userLogin}");

                User user = null;

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT UserID, UserLogin, UserName FROM Users WHERE UserLogin = @UserLogin";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserLogin", userLogin);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                user = new User
                                {
                                    UserID = (int)reader["UserID"],
                                    UserLogin = reader["UserLogin"].ToString(),
                                    UserName = reader["UserName"].ToString(),
                                };
                            }
                            else
                            {
                                Console.WriteLine($"Пользователь с логином {userLogin} не найден.");
                            }
                        }
                    }
                }

                return user;
            }
            public User GetUserById(int userId)
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT UserID, UserLogin, UserName FROM Users WHERE UserID = @UserID";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new User
                                {
                                    UserID = reader.GetInt32("UserID"),
                                    UserLogin = reader.GetString("UserLogin"),
                                    UserName = reader.GetString("UserName")
                                };
                            }
                        }
                    }
                }

                MessageBox.Show("Пользователь не найден."); // Для отладки
                return null;
            }
            public Group GetGroupById(int groupId)
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();

                using var cmd = new MySqlCommand("SELECT * FROM Groups WHERE GroupID = @id", conn);
                cmd.Parameters.AddWithValue("@id", groupId);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new Group
                    {
                        GroupID = reader.GetInt32("GroupID"),
                        GroupName = reader.GetString("GroupName")
                    };
                }

                return null;
            }
        }
            private void ViewUsers(User selectedUser)
            {
                // Получаем детали о выбранном пользователе
                var user = chatService.GetUser(selectedUser.UserLogin);

                if (user != null)
                {
                    // Обновляем элементы интерфейса
                    NameChatTextBlock.Text = $"Имя: {user.UserName}";
                    WelcomeUserTextBlock.Text = $"Добро пожаловать, {login}";

                    // Делаем панель чата видимой
                    ChatSpaceGrid.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("Пользователь не найден.");
                }
            }
        private void DisplayChatWithUser(User selectedUser)
        {
            MessagesPanel.Children.Clear();

            // Получаем ID текущего пользователя
            var currentUser = chatService.GetUser(login);

            if (currentUser != null)
            {
                var messages = chatService.GetMessagesBetweenUsers(currentUser.UserID, selectedUser.UserID);

                foreach (var message in messages)
                {
                    bool isFromCurrentUser = message.SenderID == currentUser.UserID;
                    var messageBubble = CreateMessageBubble(message.MessageText, isFromCurrentUser, message.CreatedAt.ToString("HH:mm"));
                    MessagesPanel.Children.Add(messageBubble);
                }

                MessagesPanel.Dispatcher.InvokeAsync(() =>
                {
                    MessagesPanel.UpdateLayout();
                    (MessagesPanel.Parent as ScrollViewer)?.ScrollToBottom();
                });
            }
            else
            {
                MessageBox.Show("Не удалось определить текущего пользователя.");
            }
        }
        private void ChatList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ChatList.SelectedItem is IChatItem item)
            {
                // Очищаем старые сообщения
                MessagesPanel.Children.Clear();

                if (item.IsGroup)
                {
                    var group = (Group)item;
                    selectedGroup = group;  // Сохраняем выбранную группу
                    selectedUser = null;  // Очищаем пользователя
                    UpdateHeaderForGroup(group); // Обновляем заголовок для группы
                    LoadGroupMessages(group.GroupID); // Загружаем сообщения группы
                }
                else
                {
                    var user = (User)item;
                    selectedUser = user;  // Сохраняем выбранного пользователя
                    selectedGroup = null;  // Очищаем группу
                    UpdateHeaderForUser(user); // Обновляем заголовок для пользователя
                    LoadPrivateMessages(user.UserID); // Загружаем личные сообщения
                }
            }
        }
        private void UpdateHeaderForGroup(Group group)
        {
            // Обновляем название группы
            NameChatTextBlock.Text = $"Группа: {group.GroupName}";
            currentGroupId = group.GroupID;
            currentReceiverUserId = -1;  // Получатель - группа

            // Получаем список участников группы
            var participants = GetGroupParticipants(group.GroupID);

            // Формируем строку с участниками
            string participantsText = string.Join(", ", participants.Select(u => u.UserID == currentUserId ? "Вы" : u.UserName));

            // Отображаем строку с участниками в TextBlock
            WelcomeUserTextBlock.Text = $"Участники: {participantsText}";

            // Показываем панель чата
            ChatSpaceGrid.Visibility = Visibility.Visible;
        }
        private void UpdateHeaderForUser(User user)
        {
            // Получаем текущего пользователя по логину
            var currentUser = chatService.GetUser(login);
            if (currentUser == null)
            {
                MessageBox.Show("Не удалось загрузить текущего пользователя.");
                return;
            }

            // Устанавливаем имя выбранного пользователя
            NameChatTextBlock.Text = $"Пользователь: {user.UserName}";

            // Устанавливаем приветственное сообщение с именем текущего пользователя
            WelcomeUserTextBlock.Text = $"Добро пожаловать, {currentUser.UserName}";

            // Сохраняем текущего пользователя
            currentUserId = currentUser.UserID;

            // Сбрасываем текущую группу
            currentGroupId = -1;
            currentReceiverUserId = user.UserID;

            // Отображаем панель чата
            ChatSpaceGrid.Visibility = Visibility.Visible;
        }
        private void LoadPrivateMessages(int userId)
        {
            // Загружаем сообщения из базы данных
            var messages = GetPrivateMessages(currentUserId, userId);

            foreach (var message in messages)
            {
                // Используем правильное имя свойства: MessageText
                var messageBubble = CreateMessageBubble(message.MessageText, message.IsOutgoing, message.CreatedAt.ToString("HH:mm"));
                MessagesPanel.Children.Add(messageBubble);
            }

            ScrollToBottom();
        }
        private void LoadGroupMessages(int groupId)
        {
            // Загружаем сообщения группы из базы данных
            var messages = GetGroupMessages(groupId);

            foreach (var message in messages)
            {
                // Используем правильное имя свойства: MessageText
                var messageBubble = CreateMessageBubble(message.MessageText, message.IsOutgoing, message.CreatedAt.ToString("HH:mm"));
                MessagesPanel.Children.Add(messageBubble);
            }

            ScrollToBottom();
        }
        private IEnumerable<Message> GetPrivateMessages(int currentUserId, int otherUserId)
        {
            string connectionString = "Server=sql8.freesqldatabase.com;" +
                                      "Database=sql8771867;" +
                                      "User=sql8771867;" +
                                      "Password=zhx9FVLUs5;" +
                                      "Port=3306;" +
                                      "CharSet=utf8mb4;";

            var messages = new List<Message>();

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
        SELECT SenderID, ReceiverID, MessageText, CreatedAt 
        FROM Messages
        WHERE (SenderID = @CurrentUserID AND ReceiverID = @OtherUserID)
           OR (SenderID = @OtherUserID AND ReceiverID = @CurrentUserID)
        ORDER BY CreatedAt";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CurrentUserID", currentUserId);
                    command.Parameters.AddWithValue("@OtherUserID", otherUserId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            messages.Add(new Message
                            {
                                SenderID = reader.GetInt32("SenderID"),
                                ReceiverID = reader.IsDBNull("ReceiverID") ? (int?)null : reader.GetInt32("ReceiverID"),
                                MessageText = reader.GetString("MessageText"),
                                CreatedAt = reader.GetDateTime("CreatedAt"),
                                IsOutgoing = reader.GetInt32("SenderID") == currentUserId
                            });
                        }
                    }
                }
            }

            return messages;
        }
        public List<Group> GetGroupsForUser(int userId)
        {
            var groups = new List<Group>();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string query = @"
                SELECT g.GroupID, g.GroupName
                FROM Groups g
                JOIN GroupUsers gu ON g.GroupID = gu.GroupID
                WHERE gu.UserID = @userID";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@userID", userId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            groups.Add(new Group
                            {
                                GroupID = reader.GetInt32("GroupID"),
                                GroupName = reader.GetString("GroupName")
                            });
                        }
                    }
                }
            }

            return groups;
        }
        private IEnumerable<Message> GetGroupMessages(int groupId)
        {
            string connectionString = "Server=sql8.freesqldatabase.com;" +
                                      "Database=sql8771867;" +
                                      "User=sql8771867;" +
                                      "Password=zhx9FVLUs5;" +
                                      "Port=3306;" +
                                      "CharSet=utf8mb4;";

            var messages = new List<Message>();

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
        SELECT SenderID, GroupID, MessageText, CreatedAt 
        FROM Messages
        WHERE GroupID = @GroupID
        ORDER BY CreatedAt";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@GroupID", groupId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            messages.Add(new Message
                            {
                                SenderID = reader.GetInt32("SenderID"),
                                GroupID = reader.GetInt32("GroupID"),
                                MessageText = reader.GetString("MessageText"),
                                CreatedAt = reader.GetDateTime("CreatedAt"),
                                IsOutgoing = false // Для групповых сообщений всегда false (отправлено кем-то из группы)
                            });
                        }
                    }
                }
            }

            return messages;
        }
        private void ScrollToBottom()
        {
            Dispatcher.Invoke(() =>
            {
                MessageList.ScrollToEnd();
            });
        }

        private void SelectUser(int userId)
        {
            var user = chatService.GetUserById(userId);
            if (user != null)
            {
                currentReceiverUserId = userId;
                currentGroupId = -1;
                DisplayChatWithUser(user);
            }
        }

        private void SelectGroup(int groupId)
        {
            var group = chatService.GetGroupById(groupId); // Получаем информацию о группе
            if (group != null)
            {
                NameChatTextBlock.Text = $"Группа: {group.GroupName}";
                currentGroupId = groupId;
                currentReceiverUserId = -1;

                // Получаем список участников группы
                var participants = GetGroupParticipants(groupId);

                // Формируем строку с участниками
                string participantsText = string.Join(", ", participants.Select(u => u.UserID == currentUserId ? "Вы" : u.UserName));

                // Отображаем строку в TextBlock
                WelcomeUserTextBlock.Text = $"Участники: {participantsText}";

                ChatSpaceGrid.Visibility = Visibility.Visible;
            }
        }

        public List<User> GetGroupParticipants(int groupId)
        {
            var participants = new List<User>();
            using var conn = new MySqlConnection(connectionString);
            conn.Open();

            string query = @"
        SELECT u.UserID, u.UserName 
        FROM Users u
        JOIN GroupUsers gu ON u.UserID = gu.UserID
        WHERE gu.GroupID = @groupId";

            using var cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@groupId", groupId);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                participants.Add(new User
                {
                    UserID = reader.GetInt32("UserID"),
                    UserName = reader.GetString("UserName")
                });
            }

            return participants;
        }

        private void ViewUsers(ChatItem selectedItem)
        {
            if (!selectedItem.IsGroup)
            {
                var user = chatService.GetUserById(selectedItem.Id);

                if (user != null)
                {
                    NameChatTextBlock.Text = $"Имя: {user.UserName}";
                    WelcomeUserTextBlock.Text = $"Добро пожаловать, {user.UserLogin}";
                    ChatSpaceGrid.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("Пользователь не найден.");
                }
            }
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
    public interface IChatItem
    {
        string DisplayName { get; }
        bool IsGroup { get; }
    }
    public class Group : IChatItem
    {
        public int GroupID { get; set; }
        public string GroupName { get; set; }
        public string DisplayName => GroupName;
        public bool IsGroup => true;
    }
    public class User : IChatItem
    {
        public int UserID { get; set; }
        public string UserLogin { get; set; }
        public string UserName { get; set; }
        public string DisplayName => UserName;
        public bool IsGroup => false;
    }

}
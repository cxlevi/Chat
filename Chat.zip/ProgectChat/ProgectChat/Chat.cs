﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgectChat
{
    internal class Chat
    {
        public int ChatID { get; set; }
        public string ChatName { get; set; }
        public string ChatData { get; set; }
    }
}

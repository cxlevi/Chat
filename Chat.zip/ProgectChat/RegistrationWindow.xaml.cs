﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Schema;

namespace ProgectChat
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void Registration_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginOrEmailTextBox.Text))
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Red);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                LoginOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Green);
                LoginOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(TelephoneNumberOrEmailTextBox.Text))
            {
                TelephoneNumberOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Red);
                TelephoneNumberOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else {
                TelephoneNumberOrEmailTextBox.BorderBrush = new SolidColorBrush(Colors.Green);
                TelephoneNumberOrEmailTextBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (string.IsNullOrWhiteSpace(AgainPasswordBox.Password))
            {

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
                return;
            }
            else
            {
                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            if (PasswordBox.Password != AgainPasswordBox.Password)
            {
                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Red);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                return;
            }
            else
            {

                PasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                PasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу

                AgainPasswordBox.BorderBrush = new SolidColorBrush(Colors.Green);
                AgainPasswordBox.BorderThickness = new Thickness(0, 0, 0, 2);  // Толщина рамки только снизу
            }

            MessageBox.Show("Регистрация успешна!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

      

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void EntryButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

    }
}

﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NAudio.CoreAudioApi;
using static System.Net.Mime.MediaTypeNames;

namespace ProgectChat
{
    /// <summary>
    /// Логика взаимодействия для ChatWindow.xaml
    /// </summary>
    public partial class ChatWindow : Window
    {

        private readonly MMDevice _audioDevice;
        public ChatWindow()
        {
            InitializeComponent();

            // Получение устройства вывода звука
            var deviceEnumerator = new MMDeviceEnumerator();
            _audioDevice = deviceEnumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);

            // Привязка события изменения значения ползунка громкости
            VolumeSlider.ValueChanged += VolumeSlider_ValueChanged;

            // Пример списка пользователей
            var users = new List<User>
            {
                new User { Id = "1", UsersNames = "Пользователь 1" },
                new User { Id = "2", UsersNames = "Пользователь 2" },
                new User { Id = "3", UsersNames = "Пользователь 3" },
                new User { Id = "4", UsersNames = "Пользователь 4" },
                new User { Id = "5", UsersNames = "Пользователь 5" },
                new User { Id = "6", UsersNames = "Пользователь 6" },
                new User { Id = "7", UsersNames = "Пользователь 7" },
                new User { Id = "8", UsersNames = "Пользователь 8" },
                new User { Id = "9", UsersNames = "Пользователь 9" },
                new User { Id = "10", UsersNames = "Пользователь 10" },
                new User { Id = "11", UsersNames = "Пользователь 11" },
                new User { Id = "12", UsersNames = "Пользователь 12" },
                new User { Id = "13", UsersNames = "Пользователь 13" },
                new User { Id = "14", UsersNames = "Пользователь 14" },
                new User { Id = "15", UsersNames = "Пользователь 15" },
                new User { Id = "16", UsersNames = "Пользователь 16" }
            };

            // Привязка данных к ListView
            ChooseUsersList.ItemsSource = users;
            UsersList.ItemsSource = users;

            var messages = new List<Message>
            {
                new Message{ Text = "Привет", Time = "7:57", IsUserMessage = true},
                new Message{ Text = "Привет", Time = "7:57", IsUserMessage = false}
            };

            MessageList.ItemsSource = messages;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {

        }

        
        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            ShowWithAnimation1();
        }

        private void CreateTeamButton_Click(object sender, RoutedEventArgs e)
        {
            ShowWithAnimation3();
        }

        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
        }

        private void SettingButton_Click(object sender, RoutedEventArgs e)
        {
            ShowWithAnimation2();
        }

        private void YourProfileButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ExitSettingProfileButton_Click(object sender, RoutedEventArgs e)
        {
            HideWithAnimation1();
        }

        private void ExitSettingButton_Click(object sender, RoutedEventArgs e)
        {
            HideWithAnimation2();
        }

        private void ExitSettingGroupButton_Click(object sender, RoutedEventArgs e)
        {
            HideWithAnimation3();
        }

        private void SaveOrRediting_Click(object sender, RoutedEventArgs e)
        {

        }

        

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Установка уровня громкости (значение от 0 до 1)
            _audioDevice.AudioEndpointVolume.MasterVolumeLevelScalar = (float)(e.NewValue / 100.0);
        }

        public void ShowWithAnimation1()
        {
            //ProfilePanel.Visibility = Visibility.Visible;

            var animation = new DoubleAnimation
            {
                From = -ActualWidth,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.7),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            SlideTransform1.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        public void ShowWithAnimation2()
        {
            //SettingPanel.Visibility = Visibility.Visible;

            var animation = new DoubleAnimation
            {
                From = -ActualWidth,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            SlideTransform2.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        public void ShowWithAnimation3()
        {
            //SettingPanel.Visibility = Visibility.Visible;

            var animation = new DoubleAnimation
            {
                From = -ActualWidth,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };

            SlideTransform3.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        public void HideWithAnimation1()
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = -ActualWidth,
                Duration = TimeSpan.FromSeconds(0.7),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            //animation.Completed += (s, e) => ProfilePanel.Visibility = Visibility.Collapsed;
            SlideTransform1.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        public void HideWithAnimation2()
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = -ActualWidth,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            //animation.Completed += (s, e) => SettingPanel.Visibility = Visibility.Collapsed;
            SlideTransform2.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        public void HideWithAnimation3()
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = -ActualWidth,
                Duration = TimeSpan.FromSeconds(0.8),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
            };

            //animation.Completed += (s, e) => SettingPanel.Visibility = Visibility.Collapsed;
            SlideTransform3.BeginAnimation(TranslateTransform.XProperty, animation);
        }

        private void CreateGroupButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем название группы
            string groupName = GroupNameTextBox.Text;

            // Получаем выбранных участников
            var selectedParticipants = ChooseUsersList.SelectedItems.Cast<User>()
                .Select(user => user.UsersNames)
                .ToList();

            if (string.IsNullOrEmpty(groupName) || selectedParticipants.Count == 0)
            {
                MessageBox.Show("Введите название группы и выберите участников.");
                return;
            }

            // Создаём группу
            MessageBox.Show($"Группа '{groupName}' создана с участниками: {string.Join(", ", selectedParticipants)}");

        }
    }
    /*public class MessageBackgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isUserMessage)
            {
                return isUserMessage ? new SolidColorBrush(Color.FromArgb(255, 0, 0, 0)) // Черный для исходящих
                                     : new SolidColorBrush(Color.FromArgb(255, 0, 0, 0)); // Черный для входящих
            }
            return new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }*/

    public class MessageAlignmentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isUserMessage)
            {
                return isUserMessage ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            }
            return HorizontalAlignment.Left;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class HeightOffsetConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double height && parameter is string offsetString && double.TryParse(offsetString, out double offset))
            {
                return height - offset;
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class User
    {
        public string Id { get; set; }
        public string UsersNames { get; set; }
    }

    public class Message
    {
        public string Text { get; set; }
        public string Time { get; set; }
        public bool IsUserMessage { get; set; } // Для стилизации исходящих сообщений
    }
}
